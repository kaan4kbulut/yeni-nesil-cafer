# cafer-plan — Tek komutla kurulum

**Yapacağın:**

1. `cafer-plan.zip` ve `otomatik.py` dosyalarını repo klasörünün köküne kopyala (CLAUDE.md'nin olduğu klasör). Zip'i açma.
2. Terminalde o klasöre gir ve yaz: `python otomatik.py`

Gerisini betik yapar: paketi kurar, `k-serisi` dalını açar, her aşama için taze bir Claude Code oturumu başlatır (K0 → K10), testleri koşar, kırmızıysa düzelttirir, commit atar. Terminalde ilerleme çubuğu; bitince masaüstü bildirimi.

Kesilirse tekrar `python otomatik.py` → kaldığı aşamadan sürer.
Her aşamadan sonra durmasını istersen: `python otomatik.py --dur`

**Bittiğinde bakacağın iki dosya:**
- `NOTLAR/KONTROL_LISTEN.md` — senin elle deneyeceğin şeyler (programı açıp test etmek gibi)
- `NOTLAR/SORULAR.md` — Claude'un sana sorup cevap alamadığı, geçici karar verdiği yerler

**Paketin içinde ne var** (merak edersen):
- `docs/MIMARI.md`, `docs/SEMALAR.md` — hedef mimari ve şemalar
- `YAPILACAKLAR_EK.md` — K0–K10 aşama planı (YAPILACAKLAR.md'ye birleşir)
- `CLAUDE_EKLENTI.md` — CLAUDE.md'ye eklenen kurallar
- `.claude/commands/` — `/asama`, `/kontrol`, `/hata-analiz`, `/yetenek-ekle`, `/profil`, `/sunucu`
- `.claude/agents/` — `mimar`, `denetci`
- `.claude/ilerleme/` — ilerleme çubuğu ve bildirim betikleri
- `ADIMLAR.md` — otomatik yolu kullanmak istemezsen, aynı işin elle (yapıştırarak) yapılan hâli
